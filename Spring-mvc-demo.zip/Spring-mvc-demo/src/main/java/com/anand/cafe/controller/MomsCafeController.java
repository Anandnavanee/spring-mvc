package com.anand.cafe.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class MomsCafeController {

	@RequestMapping("/cafe")
	public String showWelcomeMsg(Model model) {
		return "welcome";
	}
	
	@RequestMapping("/processOrder")
	public String orderProcessing(HttpServletRequest request,Model model) {
		
		String userInput = request.getParameter("itemType");
		
		model.addAttribute("userData",userInput);
		
		return "processOrder";
	}
}
